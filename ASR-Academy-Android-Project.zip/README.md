# ASR Academy Android App

**Package:** `pk.asr.academy`  
**App name:** ASR Academy  
**Target APK:** `ASR-Academy-debug.apk`

This project is designed for the Director of Aspire Sky Rise Educational & Technical Institute Khuzdar.

## Included in this starter Android build

- Offline-first student admission records
- S.No, student name, father's name, CNIC/B-Form, phone, address
- Course applied, course fee, admission fee
- Passport-picture selection URI
- Daily attendance
- Automatic SMS attempt for admissions, fees and absences using the phone SIM
- WhatsApp message launcher with pre-filled message
- Fee records and receipt numbers
- Course/module information from the academy brochure
- Local message queue/status
- Local backup/export to email/share
- Academy logo and details
- No paid SMS/WhatsApp API is required by this project

## Important

SMS is sent through Android's `SmsManager`, so the device/SIM/carrier may charge normal SMS fees. WhatsApp still requires internet and may require the final send action.

## Build the APK free using GitHub Actions

1. Create a free GitHub account at github.com.
2. Create a new repository named `ASR-Academy`.
3. Upload the contents of this project to the repository.
4. Commit/push to the `main` branch.
5. Open the repository's **Actions** tab.
6. Run **Build ASR Academy APK** (or push to `main`).
7. When the workflow finishes, open the workflow run.
8. Under **Artifacts**, download `ASR-Academy-debug`.
9. Extract it and install `app-debug.apk` on your Android phone.
10. On first launch, allow the **SMS** permission.

## Making a signed release APK

The workflow intentionally creates a debug APK because it can be built without storing signing keys in GitHub. For wider distribution or Play Store publishing, create a private Android signing key and add it to GitHub Actions secrets.

## Academy details

Aspire Sky Rise Educational & Technical Institute Khuzdar  
Nall Road Koshk Sonji, Khuzdar, Balochistan  
03126621454  
03312376121  
Backup email: asreducationaltechnicalinstitu@gmail.com
