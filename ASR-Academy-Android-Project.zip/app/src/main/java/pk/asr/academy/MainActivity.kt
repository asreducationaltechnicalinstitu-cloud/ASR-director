package pk.asr.academy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("asr_data", MODE_PRIVATE) }
    private val navy = Color.rgb(10, 33, 74)
    private val gold = Color.rgb(201, 151, 26)
    private val bg = Color.rgb(245, 247, 251)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestSmsPermission()
        showDashboard()
    }

    private fun requestSmsPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.SEND_SMS), 501)
        }
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 18, 18, 18)
        }
    }

    private fun header(title: String): TextView = TextView(this).apply {
        text = title
        textSize = 23f
        setTextColor(navy)
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(4, 8, 4, 14)
    }

    private fun button(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(navy)
        setOnClickListener { onClick() }
        val p = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 6, 0, 6)
        layoutParams = p
    }

    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        textSize = 16f
        setSingleLine(true)
        val p = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 3, 0, 3)
        layoutParams = p
    }

    private fun scroll(content: View): ScrollView = ScrollView(this).apply {
        addView(content)
        isFillViewport = true
    }

    private fun setScreen(v: View) { setContentView(v) }

    private fun showDashboard() {
        val root = base()
        val logo = ImageView(this).apply {
            setImageResource(pk.asr.academy.R.drawable.asr_logo)
            adjustViewBounds = true
            maxHeight = 230
            setPadding(20, 0, 20, 0)
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, 210))
        root.addView(TextView(this).apply {
            text = "ASR ACADEMY\nDirector Management System"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(navy)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 12)
        })
        root.addView(TextView(this).apply {
            text = "Aspire Sky Rise Educational & Technical Institute Khuzdar\nNall Road Koshk Sonji, Khuzdar, Balochistan\n03126621454  •  03312376121"
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 12)
        })
        root.addView(button("🎓 Student Admission") { showAdmission() })
        root.addView(button("🗓 Daily Attendance") { showAttendance() })
        root.addView(button("💰 Fee Management") { showFees() })
        root.addView(button("📚 Courses & Modules") { showCourses() })
        root.addView(button("📲 Message Queue / Alerts") { showMessages() })
        root.addView(button("💾 Backup & Export") { showBackup() })
        root.addView(button("ℹ️ Academy Details") { showDetails() })
        setScreen(scroll(root))
    }

    private fun addBack(root: LinearLayout) {
        root.addView(button("← Dashboard") { showDashboard() })
    }

    private fun showAdmission() {
        val root = base()
        root.addView(header("Student Admission"))
        val sno = field("S.No")
        val name = field("Student Name")
        val father = field("Father's Name")
        val cnic = field("CNIC / B-Form")
        val phone = field("Guardian Phone Number")
        val address = field("Address")
        val course = field("Course Applied")
        val fee = field("Course Fee")
        val admissionFee = field("Admission Fee")
        val photo = field("Passport Picture URI (optional)")
        listOf(sno,name,father,cnic,phone,address,course,fee,admissionFee,photo).forEach { root.addView(it) }

        root.addView(button("📷 Choose Passport Picture") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 701)
        })
        root.addView(button("SAVE ADMISSION + SEND SMS") {
            if (name.text.isBlank() || phone.text.isBlank()) {
                toast("Student name and guardian phone are required")
                return@button
            }
            val obj = JSONObject().apply {
                put("sno", sno.text.toString())
                put("name", name.text.toString())
                put("father", father.text.toString())
                put("cnic", cnic.text.toString())
                put("phone", phone.text.toString())
                put("address", address.text.toString())
                put("course", course.text.toString())
                put("fee", fee.text.toString())
                put("admissionFee", admissionFee.text.toString())
                put("photo", photo.text.toString())
                put("date", now())
            }
            append("students", obj)
            val msg = "Dear Parent/Guardian, ${name.text} has been enrolled at Aspire Sky Rise Educational & Technical Institute Khuzdar. Admission No: ${sno.text}. Course: ${course.text}. Thank you."
            sendSms(phone.text.toString(), msg, "Admission")
            toast("Admission saved offline. SMS queued/sent if permission is available.")
            showDashboard()
        })
        addBack(root)
        setScreen(scroll(root))
    }

    private fun showAttendance() {
        val root = base()
        root.addView(header("Daily Attendance"))
        val students = array("students")
        if (students.length() == 0) {
            root.addView(TextView(this).apply {
                text = "No students yet. Add students from Student Admission."
                textSize = 16f
                setPadding(0, 20, 0, 20)
            })
        }
        for (i in 0 until students.length()) {
            val s = students.getJSONObject(i)
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(TextView(this).apply {
                text = "${s.optString("sno")} — ${s.optString("name")}\n${s.optString("phone")}"
                textSize = 16f
                setTextColor(navy)
                setPadding(4, 8, 4, 4)
            })
            val row = LinearLayout(this)
            row.addView(button("✓ Present") {
                append("attendance", JSONObject().apply {
                    put("student", s.optString("name")); put("sno", s.optString("sno"))
                    put("status", "Present"); put("date", now())
                })
                toast("${s.optString("name")} marked present")
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("✗ ABSENT + SMS") {
                append("attendance", JSONObject().apply {
                    put("student", s.optString("name")); put("sno", s.optString("sno"))
                    put("status", "Absent"); put("date", now())
                })
                val msg = "Dear Parent/Guardian, ${s.optString("name")} was marked absent from Aspire Sky Rise Educational & Technical Institute Khuzdar today (${today()}). Please contact the institute if necessary."
                sendSms(s.optString("phone"), msg, "Absence")
                toast("Absent recorded and alert queued/sent.")
            }, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(row)
            root.addView(box)
        }
        addBack(root)
        setScreen(scroll(root))
    }

    private fun showFees() {
        val root = base()
        root.addView(header("Fee Management"))
        val students = array("students")
        val names = ArrayList<String>()
        for (i in 0 until students.length()) names.add(students.getJSONObject(i).optString("name"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names.ifEmpty { listOf("No students") })
        root.addView(spinner)
        val amount = field("Amount Paid")
        val receipt = field("Receipt No")
        root.addView(amount); root.addView(receipt)
        root.addView(button("SAVE PAYMENT + SEND SMS") {
            if (students.length() == 0) { toast("Add a student first"); return@button }
            val idx = spinner.selectedItemPosition.coerceAtLeast(0)
            val s = students.getJSONObject(idx)
            val msg = "Dear Parent/Guardian, payment of Rs. ${amount.text} for ${s.optString("name")} has been received by Aspire Sky Rise Educational & Technical Institute Khuzdar. Receipt No: ${receipt.text}. Thank you."
            append("fees", JSONObject().apply {
                put("student", s.optString("name")); put("sno", s.optString("sno"))
                put("amount", amount.text.toString()); put("receipt", receipt.text.toString()); put("date", now())
            })
            sendSms(s.optString("phone"), msg, "Fee Payment")
            toast("Payment saved offline and receipt alert queued/sent.")
            showDashboard()
        })
        root.addView(button("📄 View Recent Payments") {
            val fees = array("fees")
            val t = TextView(this)
            val sb = StringBuilder()
            for (i in fees.length()-1 downTo 0) {
                val f = fees.getJSONObject(i)
                sb.append("${f.optString("date")} | ${f.optString("student")} | Rs. ${f.optString("amount")} | ${f.optString("receipt")}\n")
            }
            t.text = if (sb.isEmpty()) "No payments yet." else sb.toString()
            t.textSize = 15f
            root.addView(t, 1)
        })
        addBack(root)
        setScreen(scroll(root))
    }

    private fun showCourses() {
        val root = base()
        root.addView(header("Courses & Modules"))
        val courses = listOf(
            "Subject Classes — Nursery to 10th Class — All Subjects",
            "Language Classes — English, Grammar, Speaking, Reading, Writing, Vocabulary",
            "Newspaper Reading Classes — Reading Skills, Vocabulary, Current Affairs, Comprehension, General Knowledge, Confident Personality",
            "Computer Classes — Typing (English), Office Automation, MS Word, MS Excel, MS PowerPoint, CIT",
            "Professional Courses — Graphics, AI, Video Editing, Web Development"
        )
        courses.forEach { c ->
            root.addView(TextView(this).apply {
                text = "• $c"
                textSize = 16f
                setTextColor(navy)
                setPadding(4, 12, 4, 12)
            })
        }
        addBack(root)
        setScreen(scroll(root))
    }

    private fun showMessages() {
        val root = base()
        root.addView(header("Message Queue / Alerts"))
        val arr = array("messages")
        if (arr.length() == 0) root.addView(TextView(this).apply {
            text = "No message events yet."
            textSize = 16f
        })
        for (i in arr.length()-1 downTo 0) {
            val m = arr.getJSONObject(i)
            root.addView(TextView(this).apply {
                text = "${m.optString("date")} • ${m.optString("type")}\nTo: ${m.optString("phone")}\n${m.optString("message")}\nStatus: ${m.optString("status")}"
                textSize = 14f
                setTextColor(Color.DKGRAY)
                setPadding(4, 10, 4, 10)
            })
            root.addView(button("Open WhatsApp for this message") {
                openWhatsApp(m.optString("phone"), m.optString("message"))
            })
        }
        addBack(root)
        setScreen(scroll(root))
    }

    private fun showBackup() {
        val root = base()
        root.addView(header("Backup & Export"))
        root.addView(TextView(this).apply {
            text = "Local-first backup. Your records remain on the device and can be exported whenever needed.\n\nBackup email: asreducationaltechnicalinstitu@gmail.com"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 16)
        })
        root.addView(button("💾 Create Backup File + Share/Email") { shareBackup() })
        root.addView(button("🧹 Reset ALL Local Data") {
            AlertDialogBuilder.confirm(this, "Delete all local ASR records?") {
                prefs.edit().clear().apply()
                toast("Local data cleared")
                showDashboard()
            }
        })
        addBack(root)
        setScreen(scroll(root))
    }

    private fun showDetails() {
        val root = base()
        root.addView(header("Academy Details"))
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.asr_logo)
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(-1, 240))
        root.addView(TextView(this).apply {
            text = "ASPIRE SKY RISE EDUCATIONAL & TECHNICAL INSTITUTE KHUZDAR\n\nNall Road Koshk Sonji, Khuzdar, Balochistan\n03126621454\n03312376121\n\nLearn Today • Lead Tomorrow\nQuality Education • Bright Future"
            textSize = 16f
            setTextColor(navy)
            setPadding(4, 16, 4, 16)
        })
        addBack(root)
        setScreen(scroll(root))
    }

    private fun sendSms(phone: String, message: String, type: String) {
        append("messages", JSONObject().apply {
            put("phone", phone); put("message", message); put("type", type); put("date", now()); put("status", "Queued")
        })
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            toast("SMS permission is required; message saved in queue.")
            return
        }
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null)
            markLatestMessageSent()
        } catch (e: Exception) {
            toast("SMS saved in queue: ${e.message ?: "send failed"}")
        }
    }

    private fun markLatestMessageSent() {
        val arr = array("messages")
        if (arr.length() == 0) return
        arr.getJSONObject(arr.length()-1).put("status", "Sent")
        prefs.edit().putString("messages", arr.toString()).apply()
    }

    private fun openWhatsApp(phone: String, message: String) {
        val normalized = phone.filter { it.isDigit() }.let {
            when {
                it.startsWith("0") -> "92" + it.drop(1)
                it.startsWith("92") -> it
                else -> it
            }
        }
        try {
            val uri = Uri.parse("https://wa.me/$normalized?text=${Uri.encode(message)}")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            toast("WhatsApp is not available on this device.")
        }
    }

    private fun shareBackup() {
        val all = JSONObject().apply {
            put("students", array("students"))
            put("attendance", array("attendance"))
            put("fees", array("fees"))
            put("messages", array("messages"))
            put("exportedAt", now())
        }.toString(2)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_EMAIL, arrayOf("asreducationaltechnicalinstitu@gmail.com"))
            putExtra(Intent.EXTRA_SUBJECT, "ASR Academy Backup ${today()}")
            putExtra(Intent.EXTRA_TEXT, all)
        }
        startActivity(Intent.createChooser(send, "Send ASR backup"))
    }

    private fun append(key: String, obj: JSONObject) {
        val arr = array(key)
        arr.put(obj)
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun array(key: String): JSONArray =
        try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    object AlertDialogBuilder {
        fun confirm(activity: Activity, message: String, yes: () -> Unit) {
            android.app.AlertDialog.Builder(activity)
                .setMessage(message)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ -> yes() }
                .show()
        }
    }
}
