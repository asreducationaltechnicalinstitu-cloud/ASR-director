# Included academy assets

- `app/src/main/res/drawable/asr_logo.jpg` — ASR logo supplied in the conversation.
- `app/src/main/res/drawable/academy_brochure.jpg` — academy details/course brochure supplied in the conversation.
