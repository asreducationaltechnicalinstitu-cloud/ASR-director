# ASR Academy currently uses no custom ProGuard rules.
